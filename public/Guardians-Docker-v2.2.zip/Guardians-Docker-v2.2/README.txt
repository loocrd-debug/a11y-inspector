가디언즈 오브 갤럭시 v2.2 — Docker 실행 패키지
=================================================

【 처음 실행 방법 】
━━━━━━━━━━━━━━━━━━

■ Windows:
  1. Docker Desktop 설치 (https://www.docker.com/products/docker-desktop/)
  2. Docker Desktop 실행 후 로그인
  3. START_DOCKER.bat 더블클릭
     → 첫 실행 시 이미지 자동 빌드 (5~10분)
     → 이후 실행은 수 초 만에 시작
  4. 브라우저에서 http://localhost:3000 접속

■ Mac / Linux:
  터미널에서:
    chmod +x start_docker.sh
    ./start_docker.sh

【 파일 구성 】
━━━━━━━━━━━━━━
  Dockerfile             ← 이미지 빌드 설정
  docker-compose.yml     ← Docker Compose 설정
  START_DOCKER.bat       ← Windows 시작
  STOP_DOCKER.bat        ← Windows 종료
  start_docker.sh        ← Mac/Linux 시작
  stop_docker.sh         ← Mac/Linux 종료
  server.cjs             ← 서버 소스
  data/
    minwon-list.xlsx     ← 민원 목록 (수정 가능)
  public/                ← 웹 화면

【 Docker 명령어 (고급) 】
━━━━━━━━━━━━━━━━━━━━━━━━━
  빌드:   docker build -t a11y-inspector .
  실행:   docker run -d -p 3000:3000 --shm-size=256m a11y-inspector
  중지:   docker stop a11y-inspector
  로그:   docker logs a11y-inspector

【 시스템 요구사항 】
━━━━━━━━━━━━━━━━━━━
  OS      : Windows 10/11, macOS 12+, Ubuntu 20.04+
  RAM     : 최소 4GB (권장 8GB)
  저장공간: 최소 2GB (Docker 이미지 ~800MB)
  Docker  : Docker Desktop 4.0 이상

【 자주 묻는 질문 】
━━━━━━━━━━━━━━━━━━
Q: 이미지 빌드가 너무 오래 걸려요
A: 첫 빌드만 5~10분 소요, 이후는 캐시로 수 초

Q: 포트 3000을 이미 쓰고 있어요
A: START_DOCKER.bat 수정 → -p 8080:3000 으로 변경
   http://localhost:8080 으로 접속

Q: 민원 목록을 수정하고 싶어요
A: data/minwon-list.xlsx 수정 후 docker restart a11y-inspector

가디언즈 오브 갤럭시 v2.3 — Docker 실행 패키지
=================================================
※ v2.3 수정 사항: 오탈자 검사 중 직렬화 오류 수정

【 처음 실행 방법 】
━━━━━━━━━━━━━━━━━━

■ Windows:
  1. Docker Desktop 설치 (https://www.docker.com/products/docker-desktop/)
  2. Docker Desktop 실행 후 로그인
  3. START_DOCKER.bat 더블클릭
     → 첫 실행 시 이미지 자동 빌드 (5~10분)
     → 이후 실행은 수 초 만에 시작
  4. 브라우저에서 http://localhost:3000 접속

■ Mac / Linux:
  터미널에서:
    chmod +x start_docker.sh
    ./start_docker.sh

【 파일 구성 】
━━━━━━━━━━━━━━
  Dockerfile             ← 이미지 빌드 설정
  docker-compose.yml     ← Docker Compose 설정
  START_DOCKER.bat       ← Windows 시작
  STOP_DOCKER.bat        ← Windows 종료
  start_docker.sh        ← Mac/Linux 시작
  stop_docker.sh         ← Mac/Linux 종료
  server.cjs             ← 서버 소스 (v2.3 수정본)
  data/
    minwon-list.xlsx     ← 민원 목록 (수정 가능)
  public/                ← 웹 화면

【 Docker 명령어 (고급) 】
━━━━━━━━━━━━━━━━━━━━━━━━━
  빌드:   docker build -t a11y-inspector .
  실행:   docker run -d -p 3000:3000 --shm-size=256m a11y-inspector
  중지:   docker stop a11y-inspector
  로그:   docker logs a11y-inspector

【 시스템 요구사항 】
━━━━━━━━━━━━━━━━━━━
  OS      : Windows 10/11, macOS 12+, Ubuntu 20.04+
  RAM     : 최소 4GB (권장 8GB)
  저장공간: 최소 2GB (Docker 이미지 ~800MB)
  Docker  : Docker Desktop 4.0 이상
